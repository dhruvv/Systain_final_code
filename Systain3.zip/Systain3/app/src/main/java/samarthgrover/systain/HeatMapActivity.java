package samarthgrover.systain;

import android.graphics.Color;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;

import java.util.ArrayList;

public class HeatMapActivity extends BaseMapActivity {

    public HeatmapTileProvider Provider;

    @Override
    protected void initMapSettings() {
        ArrayList<WeightedLatLng> locations = generateLocations();
        Provider = new HeatmapTileProvider.Builder().weightedData(locations).build();
        Provider.setRadius(40);
        Provider.setOpacity(0.8);
        GoogleMap.addTileOverlay(new TileOverlayOptions().tileProvider(Provider));
    }

    private ArrayList<WeightedLatLng> generateLocations() {

        ArrayList<WeightedLatLng> locations = new ArrayList<WeightedLatLng>();

        double lat = 17.419088;
        double lng = 78.363908;
        double weight = LoginActivity.tur;

        if (weight >= 2700) //Transparent
        {
            int[] ALT_HEATMAP_GRADIENT_COLORS = {
                    Color.argb(0, 255, 255, 255),
                    Color.argb(255 / 3 * 2, 0, 255, 255),
                    Color.rgb(0, 191, 255),
                    Color.rgb(0, 0, 127),
                    Color.rgb(255, 0, 0)
            };
            float[] ALT_HEATMAP_GRADIENT_START_POINTS = {
                    0.0f, 0.10f, 0.20f, 0.60f, 1.0f
            };
            Gradient ALT_HEATMAP_GRADIENT = new Gradient(ALT_HEATMAP_GRADIENT_COLORS,
                    ALT_HEATMAP_GRADIENT_START_POINTS);
            Provider.setGradient(ALT_HEATMAP_GRADIENT);
        }
        else if (weight < 2700 && weight >= 2000) //Green
        {
            int[] ALT_HEATMAP_GRADIENT_COLORS = {
                    Color.argb(0, 0, 255, 255),
                    Color.argb(255 / 3 * 2, 0, 255, 255),
                    Color.rgb(0, 191, 255),
                    Color.rgb(0, 0, 127),
                    Color.rgb(255, 0, 0)
            };
            float[] ALT_HEATMAP_GRADIENT_START_POINTS = {
                    0.0f, 0.10f, 0.20f, 0.60f, 1.0f
            };
            Gradient ALT_HEATMAP_GRADIENT = new Gradient(ALT_HEATMAP_GRADIENT_COLORS,
                    ALT_HEATMAP_GRADIENT_START_POINTS);
            Provider.setGradient(ALT_HEATMAP_GRADIENT);
        }
        else if (weight < 2000 && weight >= 1000) //Yellow
        {
            int[] ALT_HEATMAP_GRADIENT_COLORS = {
                    Color.argb(0, 0, 255, 255),
                    Color.argb(255 / 3 * 2, 0, 255, 255),
                    Color.rgb(0, 191, 255),
                    Color.rgb(0, 0, 127),
                    Color.rgb(255, 0, 0)
            };
            float[] ALT_HEATMAP_GRADIENT_START_POINTS = {
                    0.0f, 0.10f, 0.20f, 0.60f, 1.0f
            };
            Gradient ALT_HEATMAP_GRADIENT = new Gradient(ALT_HEATMAP_GRADIENT_COLORS,
                    ALT_HEATMAP_GRADIENT_START_POINTS);
            Provider.setGradient(ALT_HEATMAP_GRADIENT);
        }
        else //Red
        {
            int[] ALT_HEATMAP_GRADIENT_COLORS = {
                    Color.argb(0, 0, 255, 255),
                    Color.argb(255 / 3 * 2, 0, 255, 255),
                    Color.rgb(0, 191, 255),
                    Color.rgb(0, 0, 127),
                    Color.rgb(255, 0, 0)
            };
            float[] ALT_HEATMAP_GRADIENT_START_POINTS = {
                    0.0f, 0.10f, 0.20f, 0.60f, 1.0f
            };
            Gradient ALT_HEATMAP_GRADIENT = new Gradient(ALT_HEATMAP_GRADIENT_COLORS,
                    ALT_HEATMAP_GRADIENT_START_POINTS);
            Provider.setGradient(ALT_HEATMAP_GRADIENT);
        }

        LatLng coordinates = new LatLng(lat, lng);

        locations.add(new WeightedLatLng(coordinates, weight));

        return locations;
    }
}
